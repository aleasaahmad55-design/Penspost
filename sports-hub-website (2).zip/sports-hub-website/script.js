const nav=document.getElementById('nav');document.getElementById('menuBtn').addEventListener('click',()=>nav.classList.toggle('open'));
const modal=document.getElementById('modal'),title=document.getElementById('modalTitle'),input=document.getElementById('modalInput');
function showModal(t,ph){title.textContent=t;input.placeholder=ph;modal.classList.add('show');input.focus()}
document.getElementById('searchBtn').addEventListener('click',()=>showModal('بحث في الموقع','اكتب كلمة البحث...'));
document.getElementById('loginBtn').addEventListener('click',()=>showModal('تسجيل الدخول','البريد الإلكتروني أو اسم المستخدم'));
document.getElementById('closeModal').addEventListener('click',()=>modal.classList.remove('show'));
modal.addEventListener('click',e=>{if(e.target===modal)modal.classList.remove('show')});
document.getElementById('modalAction').addEventListener('click',()=>{alert(input.value?`تم استلام: ${input.value}`:'يرجى إدخال البيانات');modal.classList.remove('show')});
document.querySelectorAll('.tabs button').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.tabs button').forEach(x=>x.classList.remove('selected'));b.classList.add('selected')}));
